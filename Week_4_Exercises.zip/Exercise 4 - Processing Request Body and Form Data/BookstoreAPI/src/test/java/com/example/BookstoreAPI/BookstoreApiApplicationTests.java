package com.example.BookstoreAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

@SpringBootTest
class BookstoreApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
